<section class="category-header-area">
    <div class="container-lg">
        <div class="row text-center">
            <div class="col">
                <div class="page-not-found-banner">
                    <span class="page_not_found_message text-secondary">
                        Halaman tidak ditemukan
                    </span>
                    <a href="<?php echo site_url('home'); ?>" class="btn red" id="">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>